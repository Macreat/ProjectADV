/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>



/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */


#include "ring_buffer.h"
#include"ssd1306.h"
#include"ssd1306_fonts.h"
#include <stdio.h>
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;

I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

uint8_t data_usart2;
uint8_t newline[] = "\r\n";


char uart_buff[20];
uint16_t raw_value_NTC, raw_value_LDR;


#define BUFFER_CAPACITY 10
uint8_t keyboard_buffer_memory[BUFFER_CAPACITY];
ring_buffer_t keyboard_ring_buffer;
uint8_t first_key_pressed = 0;
uint8_t cursor_x_position = 10;
uint8_t cursor_y_position = 30;
uint8_t max_cursor_x_position = 80;

#define MAX_DISPLAY_CHARS 20 // SIZE of chart and screen

//buffer to store the key sequence
static char display_buffer[MAX_DISPLAY_CHARS + 1]; // +1 for nule value
static uint8_t buffer_index = 0;

// variables for actual cursor position on screen
static uint8_t cursor_x = 10;
static uint8_t cursor_y = 30;
// adding variables for LED control
#define SYSTEM_LED_GPIO_Port GPIOA
#define SYSTEM_LED_Pin GPIO_PIN_5

volatile uint8_t passwordCorrect = 0;

// declaring data receivde frfom uart :
#define USART2_RB_LEN 1
uint8_t usart2_data = 0xFF;
uint8_t usart2_buffer[USART2_RB_LEN];
ring_buffer_t usart2_rb;
uint32_t usart_input_value = 0;





/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void PeriphCommonClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC2_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */



/*
 * Function to redirect printf output to UART.
 *
 * Purpose:
 * This function overrides the standard `_write` function to allow the
 * usage of `printf` in embedded systems without a standard output. It
 * redirects the printf output to UART for debugging or serial communication.
 *
 * Parameters:
 * - file: Not used, required by the function signature.
 * - ptr: Pointer to the data to be transmitted.
 * - len: Length of the data to be transmitted.
 *
 * Functionality:
 * - It sends the data pointed to by `ptr` via UART using HAL_UART_Transmit.
 * - It returns the length of the data transmitted.
 *
 * Use case:
 * By using this function, any call to `printf` will output the message
 * to the UART interface, which can be monitored with a serial console.
 */

int _write(int file, char *ptr, int len)
{
  // to using printf
  HAL_UART_Transmit(&huart2, (uint8_t *)ptr, len, 10);
  return len;
}

//* USART2 Callback ------------------------------------------------------------*/
/* UART Callback: Receives data and processes it */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2) {
        // Store digits received from USART2 into the ring buffer
        if (usart2_data >= '0' && usart2_data <= '9') {
            ring_buffer_write(&usart2_rb, usart2_data);
        }

        // Check if the buffer has 6 digits and process the input
        if (ring_buffer_size(&usart2_rb) >= 6) {
            char usart_str[7];
            for (int i = 0; i < 6; i++) {
                ring_buffer_read(&usart2_rb, (uint8_t *)&usart_str[i]);
            }
            //usart_str[6] = '\0';
            usart_input_value = strtol(usart_str, NULL, 10);
            printf("USART Input: %lu\r\n", usart_input_value);

            // Display value on OLED
            ssd1306_Fill(Black);
            ssd1306_SetCursor(10, 30);
            char usart_oled_str[20];
            sprintf(usart_oled_str, "USART: %lu", usart_input_value);
            ssd1306_WriteString(usart_oled_str, Font_6x8, White);
            ssd1306_UpdateScreen();

        }
        if (usart_input_value == "123"){
        	passwordCorrect = 1 ;
        }

        HAL_UART_Receive_IT(&huart2, &usart2_data, 1);
    }
}
/*
 *

 void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  /* Data received in USART2
  if (huart->Instance == USART2) {
	  usart2_rx = USART2->RDR; // leyendo el byte recibido de USART2
	  ring_buffer_write(&usart2_rb, usart2_rx);
	  }
  if (huart->Instance == USART3) {
	  usart3_rx = USART3->RDR; // leyendo el byte recibido de USART2
	  ring_buffer_write(&usart3_rb, usart3_rx);
	  }

	  // put the data received in buffer
	  HAL_UART_Receive_IT(&huart2, &usart2_rx, 1); // enable interrupt to continue receiving
	  ATOMIC_SET_BIT(USART2->CR1, USART_CR1_RXNEIE); // usando un funcion mas liviana para reducir memoria
  }


 */





/*
 * Function to handle external interrupt callbacks for GPIO pins (keypad input).
 *
 * Purpose:
 * This function is called when a GPIO interrupt occurs. It scans the keypad for the pressed key,
 * handles special cases ('*' to reset the sequence, '#' to validate the password), and updates
 * the OLED display and UART based on the input.
 *
 * Parameters:
 * - GPIO_Pin: The pin number where the interrupt was triggered.
 *
 * Functionality:
 * - Detects the key pressed on the keypad.
 * - If '*' is pressed, the input sequence is reset.
 * - If a valid key is pressed, it is added to the ring buffer and displayed on the OLED.
 * - If '#' is pressed, the entered sequence is validated against a predefined correct sequence.
 * - The result of the validation (correct or incorrect) is displayed on the OLED and transmitted via UART.
 * - The buffer is reset after validation.
 */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	uint8_t key_pressed = keypad_scan(GPIO_Pin);

	    if (key_pressed != 0xFF) {
	        // when '*' is pressed, the sequence is RESET
	        if (key_pressed == '*') {
	            ring_buffer_reset(&keyboard_ring_buffer);
	            memset(display_buffer, 0, sizeof(display_buffer)); //clean actual buffer on the screen
	            buffer_index = 0; // reset index on buffer

	            ssd1306_Fill(Black);
	            ssd1306_SetCursor(10, 20);
	            ssd1306_WriteString("sequence restarted", Font_6x8, White);
	            ssd1306_UpdateScreen();
	            HAL_UART_Transmit(&huart2, (uint8_t*)"Sequence restarted\n\r", 22, 10);
	            return;
	        }

	        // Write the key to the ring buffer
	        if (key_pressed != '#') {
	            ring_buffer_write(&keyboard_ring_buffer, key_pressed);

	            // add chart to the buffer
	            if (buffer_index < MAX_DISPLAY_CHARS) {
	                display_buffer[buffer_index++] = key_pressed;
	                display_buffer[buffer_index] = '\0'; // Null-terminar el buffer

	                // clean screen and show buffer content on screen
	                ssd1306_Fill(Black);
	                ssd1306_SetCursor(10, 30);
	                ssd1306_WriteString(display_buffer, Font_6x8, White);
	                ssd1306_UpdateScreen();

	                // send chart via UART
	                HAL_UART_Transmit(&huart2, &key_pressed, 1, 10);
	            }
	            return;
	        }



	        // proccoed when  '#' is pressed , we verify the password entered



	        uint8_t byte2 = 0;
	        uint8_t id_incorrect2 = 0;
	        uint8_t my_id2[] = "123";  // correct sequence

	        // Read from buffer and compare with correct key
	        for (uint8_t idx2 = 0; idx2 < sizeof(my_id2) - 1; idx2++) {
	            if (ring_buffer_read(&keyboard_ring_buffer, &byte2) != 0) {
	                if (byte2 != my_id2[idx2]) {
	                    id_incorrect2 = 1;  // Mark as incorrect if no match


	                    break;
	                }
	            } else {
	                id_incorrect2 = 1;  // if there is no space in buffer
	                break;
	            }
	        }

	        HAL_UART_Transmit(&huart2, (uint8_t*)"\n", 1, 10);

	        if (!id_incorrect2) {
	            // success
	            ssd1306_Fill(Black);
	            ssd1306_SetCursor(10, 20);
	            ssd1306_WriteString("correct sequence\n\r", Font_6x8, White);
	            ssd1306_UpdateScreen();
	            HAL_UART_Transmit(&huart2, (uint8_t*)"correct sequence\n\r", 21, 10);
	            HAL_UART_Transmit(&huart2, (uint8_t*)"starting...\n\r", 14, 10);
	            passwordCorrect = 1 ;
	            return;



	        } else {
	            //  error
	            ssd1306_Fill(Black);
	            ssd1306_SetCursor(10, 20);
	            ssd1306_WriteString("error. Try again ", Font_6x8, White);
	            ssd1306_UpdateScreen();
	            HAL_UART_Transmit(&huart2, (uint8_t*)" incorrect sequence. Try again  \n\r", 12, 10);

	        }

	        // reset buffer after validation
	        ring_buffer_reset(&keyboard_ring_buffer);
	        memset(display_buffer, 0, sizeof(display_buffer)); // clean buffer on screen
	        buffer_index = 0; // reset index buffer
	        cursor_x = 10;  //Resets the horizontal cursor position
	        cursor_y = 30;  // Restarts the vertical position of the course

	    }
}









/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* Configure the peripherals common clocks */
  PeriphCommonClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_USART2_UART_Init();
  MX_ADC2_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
  ring_buffer_init(&keyboard_ring_buffer, keyboard_buffer_memory, BUFFER_CAPACITY);
  ssd1306_Init();
  ssd1306_Fill(Black);
  ssd1306_SetCursor(10,20);
  ssd1306_WriteString("Starting...\r\n",Font_6x8,White);
  ssd1306_UpdateScreen();



  HAL_UART_Receive_IT(&huart2, &usart2_data, 1);
  ring_buffer_init(&usart2_rb, usart2_buffer, USART2_RB_LEN);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  printf("Starting...\r\n");

  while (1)
  {

	  if(passwordCorrect)
	  	  {
	  		  for (int i = 0 ; i < 1; i ++){
	  			 printf("correct password. Welcome to our quality air system \r\n");
	  			 ssd1306_Fill(Black);
				  ssd1306_SetCursor(10, 20);
				  ssd1306_WriteString("Welcome to our quality air system ", Font_6x8, White);
				  ssd1306_UpdateScreen();
	  			 passwordCorrect =0  ;
	  		  }

	  		  while(1)
	  		  {
	  			 // adding logic to implement heartbeat
	  			    static uint32_t last_heartbeat_time = 0;
	  			    if (HAL_GetTick() - last_heartbeat_time >= 500) // toggling for 1Hz (500ms on / 500ms off)
	  			    {
	  			      HAL_GPIO_TogglePin(GPIOA, SYSTEM_LED_Pin);
	  			      last_heartbeat_time = HAL_GetTick();
	  			      // HAL_UART_Transmit(&huart2, HB, sizeof(HB) - 1, 100);
	  			    }

	  			    // starting system

				  // LDR read and display on OLED
				  HAL_ADC_Start(&hadc1);
				  HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);
				  raw_value_LDR = HAL_ADC_GetValue(&hadc1);

				  // Convert LDR value to string and display it
				  char buffer_LDR[10]; // Buffer to hold the LDR value as a string
				  sprintf(buffer_LDR, "%4hu", raw_value_LDR); // Convert to 4-digit unsigned short
				  ssd1306_SetCursor(50, 1);  // Set cursor to top-right of the OLED
				  ssd1306_WriteString(buffer_LDR, Font_6x8, White); // Write LDR value
				  ssd1306_UpdateScreen();

				  // Send LDR value over UART
				  sprintf(uart_buff, "LDR : %hu \r\n", raw_value_LDR);
				  HAL_UART_Transmit(&huart2, (uint8_t*)uart_buff, strlen(uart_buff), HAL_MAX_DELAY);



					// NTC read and display on OLED
					HAL_ADC_Start(&hadc2);
					HAL_ADC_PollForConversion(&hadc2, HAL_MAX_DELAY);
					raw_value_NTC = HAL_ADC_GetValue(&hadc2);

					// Convert NTC value to string and display it
					char buffer_NTC[10]; // Buffer to hold the NTC value as a string
					sprintf(buffer_NTC, "%4hu", raw_value_NTC); // Convert to 4-digit unsigned short
					ssd1306_SetCursor(80,1);  // Adjust the cursor position slightly below LDR
					ssd1306_WriteString(buffer_NTC, Font_6x8, White); // Write NTC value
					ssd1306_UpdateScreen();

					// Send NTC value over UART
					sprintf(uart_buff, "NTC : %hu \r\n", raw_value_NTC);
					HAL_UART_Transmit(&huart2, (uint8_t*)uart_buff, strlen(uart_buff), HAL_MAX_DELAY);
					HAL_Delay(1000);

	  			  		 	   //conditional for LDR incidence
	  			  		  if ( raw_value_LDR > 3000 ||  HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13)== 0 ){
	  			  			  	  HAL_GPIO_WritePin(LD4_GPIO_Port, LD4_Pin , 1 );
	  			  			  	  ssd1306_SetCursor(80, 50);
	  			  			  	  ssd1306_WriteString("optimal light detected", Font_6x8, White);
	  			  			  	  ssd1306_UpdateScreen();
	  			  			  	  HAL_UART_Transmit(&huart2, (uint8_t*)" optimal light detected \n\r", 12, 10);

	  			  		  }else{
	  			  			  	  HAL_GPIO_WritePin(LD4_GPIO_Port, LD4_Pin , 0 );

	  			  		  }

	  			  		 	   // conditional for NTC incidence

	  			  		 if (raw_value_NTC <= 1700) {
	  						  // LD1 control
	  						  HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, 1);
	  						  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, 0);
	  						  HAL_GPIO_WritePin(LD3_GPIO_Port, LD3_Pin, 0);
	  						  ssd1306_Fill(Black);
							  ssd1306_SetCursor(10, 20);
							  ssd1306_WriteString("Safe temperature", Font_6x8, White);
							  ssd1306_UpdateScreen();
							  HAL_UART_Transmit(&huart2, (uint8_t*)" Safe temperature threshold \n\r", 12, 10);
	  					  }
	  					  else if (raw_value_NTC > 1700 && raw_value_NTC <= 3300) {
	  						  // turn on LD2
	  						  HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, 1);
	  						  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, 1);
	  						  HAL_GPIO_WritePin(LD3_GPIO_Port, LD3_Pin, 0);
	  						  ssd1306_Fill(Black);
							  ssd1306_SetCursor(10, 20);
							  ssd1306_WriteString("Higher temperature ", Font_6x8, White);
							  ssd1306_UpdateScreen();
							  HAL_UART_Transmit(&huart2, (uint8_t*)" Higher than average temperature threshold \n\r", 12, 10);
}
	  					  else if (raw_value_NTC > 2700) {
	  						  // Activa el LED3
	  						  HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, 1);
	  						  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, 1);
	  						  HAL_GPIO_WritePin(LD3_GPIO_Port, LD3_Pin, 1);
	  						  ssd1306_Fill(Black);
							  ssd1306_SetCursor(10, 20);
							  ssd1306_WriteString("H HIGH tempt detected.", Font_6x8, White);
							  ssd1306_UpdateScreen();
							  HAL_UART_Transmit(&huart2, (uint8_t*)" Take care.High tempt detected. \n\r", 12, 10);
	  					  }
	  		  	  }


	  	  }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief Peripherals Common Clock Configuration
  * @retval None
  */
void PeriphCommonClock_Config(void)
{
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the peripherals clock
  */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCCLKSOURCE_PLLSAI1;
  PeriphClkInit.PLLSAI1.PLLSAI1Source = RCC_PLLSOURCE_HSI;
  PeriphClkInit.PLLSAI1.PLLSAI1M = 1;
  PeriphClkInit.PLLSAI1.PLLSAI1N = 8;
  PeriphClkInit.PLLSAI1.PLLSAI1P = RCC_PLLP_DIV7;
  PeriphClkInit.PLLSAI1.PLLSAI1Q = RCC_PLLQ_DIV2;
  PeriphClkInit.PLLSAI1.PLLSAI1R = RCC_PLLR_DIV2;
  PeriphClkInit.PLLSAI1.PLLSAI1ClockOut = RCC_PLLSAI1_ADC1CLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_MultiModeTypeDef multimode = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the ADC multi-mode
  */
  multimode.Mode = ADC_MODE_INDEPENDENT;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_5;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_12CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief ADC2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC2_Init(void)
{

  /* USER CODE BEGIN ADC2_Init 0 */

  /* USER CODE END ADC2_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC2_Init 1 */

  /* USER CODE END ADC2_Init 1 */

  /** Common config
  */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;
  hadc2.Init.Resolution = ADC_RESOLUTION_12B;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc2.Init.LowPowerAutoWait = DISABLE;
  hadc2.Init.ContinuousConvMode = DISABLE;
  hadc2.Init.NbrOfConversion = 1;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc2.Init.DMAContinuousRequests = DISABLE;
  hadc2.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc2.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_6;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_2CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC2_Init 2 */

  /* USER CODE END ADC2_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x10D19CE4;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LD1_Pin|SYSTEM_LED_Pin|LD2_Pin|LD3_Pin
                          |MOTORX_Pin|MOTORY_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD4_GPIO_Port, LD4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(ROW_1_GPIO_Port, ROW_1_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, ROW_2_Pin|ROW_4_Pin|ROW_3_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LD1_Pin SYSTEM_LED_Pin LD2_Pin LD3_Pin
                           ROW_1_Pin MOTORX_Pin MOTORY_Pin */
  GPIO_InitStruct.Pin = LD1_Pin|SYSTEM_LED_Pin|LD2_Pin|LD3_Pin
                          |ROW_1_Pin|MOTORX_Pin|MOTORY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LD4_Pin ROW_2_Pin ROW_4_Pin ROW_3_Pin */
  GPIO_InitStruct.Pin = LD4_Pin|ROW_2_Pin|ROW_4_Pin|ROW_3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : COL_1_Pin */
  GPIO_InitStruct.Pin = COL_1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(COL_1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : COL_4_Pin */
  GPIO_InitStruct.Pin = COL_4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(COL_4_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : COL_2_Pin COL_3_Pin */
  GPIO_InitStruct.Pin = COL_2_Pin|COL_3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
